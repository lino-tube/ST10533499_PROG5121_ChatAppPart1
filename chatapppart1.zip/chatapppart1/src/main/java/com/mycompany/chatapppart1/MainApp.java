/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
//this is where all my programs will be stored
package com.mycompany.chatapppart1;

//imports the Scanner class so we can take input from the user
import java.util.Scanner;
/**
 *
 * @author Student
 */

//the programm will now be interacting with user
public class MainApp {
    public static void main(String[] args) {
    
        //the scanner will allow the user to enter their details
        Scanner input = new Scanner(System.in);
        
        /*
         an object of the login class is being created, 
         so we can call its methods
        */
        Login login = new Login();
        
        //user registration process for the chat app
        System.out.println("=== USER REGISTRATION ===");
        
        System.out.println("Enter a username: ");
        String username = input.nextLine();
        
        System.out.println("Enter a password: ");
        String password = input.nextLine();
        
        System.out.println("Enter your South African phone number (+27...): ");
        String phoneNumber = input.nextLine();
        
        //registerUser method gets called and the message it returns gets stored
        String response = login.registerUser(username, password, phoneNumber);
        
        //registration message is being shown
        System.out.println(response);
        
        //user login process for the chat app 
        System.out.println("\n=== USER LOGIN ===");
        
        System.out.println("Enter your username: ");
        String loginUsername = input.nextLine();
        
        System.out.println("Enter your password: ");
        String loginPassword = input.nextLine();
        
        //loginUser method gets called to check if the details entered matches the stored ones
        boolean loggedIn = login.loginUser(loginUsername, loginPassword);
        
        //The correct login message gets displayed to the user
        String loginMessage = login.returnLoginStatus(loggedIn);
        System.out.println(loginMessage);
    }
}
